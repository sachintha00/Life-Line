		
		var loginSignUp = document.getElementById('loginSignUp');
		var signUpButton = document.getElementById('signUpButton');
		var signInButton = document.getElementById('signInButton');
		var signup = document.getElementById('signup');
		var signin = document.getElementById('signin');


		var su_student = document.getElementById('su_student');
		var su_teacher = document.getElementById('su_teacher');
		var su_principal = document.getElementById('su_principal');

		var student2 = document.getElementById('student2');
		var student3 = document.getElementById('student3');
		var student2Next = document.getElementById('student2Next');
		var student3Next = document.getElementById('student3Next');

		var student2Back = document.getElementById('student2Back');
		var student3Back = document.getElementById('student3Back');

		var img1 = document.querySelector('.img-1');
		var img2 = document.querySelector('.img-2');

		signUpButton.addEventListener('click',function(){
			this.classList.toggle('dropDown');
			this.parentNode.querySelector('.multi-register').classList.toggle('active');
		})

		su_student.addEventListener('click',function(){
			loginSignUp.classList.add('register');
			signin.style.transform = 'scale(0)';
			
			setTimeout(function(){
				signin.style.display = 'none';
				signup.style.transform = 'scale(1)';
			},1200)

			setTimeout(function(){
				img1.style.transform = 'translateY(-50%) scale(0)';
				img2.style.transform = 'translateY(-50%) scale(1)';
			},300)
		})
		signInButton.addEventListener('click',function(){
			signUpButton.classList.remove('dropDown');
			document.querySelector('.multi-register').classList.remove('active');
			loginSignUp.classList.remove('register');
			signup.style.transform = 'scale(0)';
				signin.style.display = 'flex';

			
			setTimeout(function(){
				signin.style.transform = 'scale(1)';
			},1200)

			setTimeout(function(){
				img1.style.transform = 'translateY(-50%) scale(1)';
				img2.style.transform = 'translateY(-50%) scale(0)';
			},300)
		})

		student2Next.addEventListener('click',function() {
			signup.style.transform = 'scale(0)';
			setTimeout(function(){
				student2.style.transform = 'scale(1)';
			},500);
		})

		student3Next.addEventListener('click',function() {
			signup.style.transform = 'scale(0)';
			student2.style.transform = 'scale(0)';
			setTimeout(function(){
				student3.style.transform = 'scale(1)';
			},500);
		})

		student2Back.addEventListener('click',function(){
			student2.style.transform = 'scale(0)';
			setTimeout(function(){
				signup.style.transform = 'scale(1)';
			},500);
		})

		student3Back.addEventListener('click',function(){
			student3.style.transform = 'scale(0)';
			signup.style.transform = 'scale(0)';
			setTimeout(function(){
				student2.style.transform = 'scale(1)';
			},500);
		})