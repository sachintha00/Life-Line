const contactForm = document.getElementById('contactForm');
const email = document.getElementById('email');
const mobile = document.getElementById('mobile');

contactForm.addEventListener('submit',(e)=>{
    e.preventDefault();
    contactValidation();
});

function contactValidation(){
    const emailvalue = email.value.trim();
    const mobilevalue = mobile.value.trim();

    setFormError(email,"check your email.....");
}


function setFormError(input,message){
    const formControl = input.parentElement;
    const label = formControl.querySelector('label');

    label.innerText = message;
}

