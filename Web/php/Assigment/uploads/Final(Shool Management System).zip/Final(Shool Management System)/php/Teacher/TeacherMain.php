<?php 
require_once('../Connection.php');
include('../logic.php'); 
session_start();
?>

<?php 
    if(!isset($_SESSION['id'])){
        header("Location:../login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/Student/StudentMenu.css" type="text/css">
    <link rel="stylesheet" href="../../css/navigationBarStyle.css" type="text/css">
    <link rel="stylesheet" href="../../css/Student/StudentDashboardStyle.css" type="text/css">
    <link rel="stylesheet" href="../../css/Student/AllStyle.css" type="text/css">
    <link rel="stylesheet" href="../../css/Student/sub" type="text/css">
    <title>Document</title>
</head>
<body>

    <header>
        <div class="navigation">
            <div class="logo">
                <ul class="nav-bar">
                    <li><img src="../../resource/logo.svg" alt="Logo"></li>
                    <li><h1>LIFE LINE</h1></li>
                </ul>
            </div>
            <div class="menu">
                <h3>Sachintha Madhawa</h3>
                <p>Grade 12</p>
                <ul>
                    <li><img src="../../resource/Profile DashBoard.png" alt=""><a href="TeacherMain.php">Dashboard</a></li>
                    <li><img src="../../resource/editProfile.png" alt=""><a href="../../php/Student/profileEdit.php">Edit Profile</a></li>
                    <li><img src="../../resource/signOut.png" alt=""><a href="../logOut.php">Sign Out</a></li>
                    <!-- <li><a href="#">Logout</a></li>
                    <li><a href="#">Logout</a></li> -->
                </ul>
            </div><!--div class="menu"-->
            <div class="nav-bar">
                <nav>
                    <ul class="nav-panel">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li ><a href="#" id="profile">Sign In</a></li>
                    </ul><!--ul class="nav-panel"-->
                </nav><!--nav-->
            </div><!--div class="nav-bar"-->
        </div>
    </header>

    <!-- Menu Start -->

    <nav class="side-menu">
        <ul>
            <li class="logo">
                <a href=""><img src="../../resource/logo.svg" alt="" id="logo" class="logo-top">LIFE LINE</a>
                <i><a href=""><img src="../../resource/Arrow.png" alt="" class="menu-toggle"></a></i>
            </li>
            
            <div class="menu-items">

                <li class="dashboard">
                    <a href="../Teacher/TeacherMain.php" class="item list btn">
                        <i><img src="../../resource/dashBoard.png" alt=""></i>
                        <span>Dashboard</span>
                    </a>
                </li><!--li class="dashboard"-->
    
                <li class="News-Event">
                    <a href="" class="item list">
                        <i><img src="../../resource/Events.png" alt=""></i>
                        <span>News And Events</span>
                    </a>
                </li><!--li class="News-Event"-->
    
                <li class="Subjects">
                    <a href="../Teacher/TeacherGrade.php" class="item list">
                        <i><img src="../../resource/Subject.png" alt=""></i>
                        <span>Grades</span>
                    </a>
                </li><!--li class="Subjects"-->

            </div><!--div class="menu-items"-->

        </ul>
    </nav>

    <!-- Menu end -->

    <div class="page-wrapper">

        <div class="allBox">

            <div class="welcome-area">
                <div class="stdash1">
                    <img src="../../resource/studentDash1.png" alt="" id="stdash1">
                </div>
                <img src="../../resource/studentDash.svg" alt="" id="stdash2">
            </div><!--div class="welcome-area"-->


            <div class="prgrssEvents">

                <div class="progress PEbox">
                    <h3>Your Progress</h3>
                    <div class="subectWithProgrss">
                        <div class=" sub Eng">
                            <a href="#" class="subectProgress">English</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">

                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class=" sub Eng"-->

                        <div class="sub Sci">
                            <a href="#" class="subectProgress">Science</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub Sci"-->

                        <div class="sub Math">
                            <a href="#" class="subectProgress">Maths</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub Math"-->

                        <div class="sub Sinhala">
                            <a href="#" class="subectProgress">Sinhala</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress">-->
                        </div><!--div class="sub Sinhala"-->

                        <div class="sub Religion">
                            <a href="#" class="subectProgress">Religion</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub Religion"-->

                        <div class="sub Hist">
                            <a href="#" class="subectProgress">History</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub Hist"-->

                        <div class="sub group1">
                            <a href="#" class="subectProgress">Group 1</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub group1"-->

                        <div class="sub group2">
                            <a href="#" class="subectProgress">Group 2</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress">-->
                        </div><!--div class="sub group2"-->

                        <div class="sub group3">
                            <a href="#" class="subectProgress">Group 3</a>
                            <div class="progress subectProgress">
                                <div class="progress-done">
                                    
                                </div><!--div class="progress-done"-->
                            </div><!--div class="progress subectProgress"-->
                        </div><!--div class="sub group3"-->

                    </div><!--div class="subectWithProgrss"-->
                </div><!--div class="progress PEbox"-->
    
                <div class="Events PEbox">
                    <h3>Lorem, ipsum dolor.</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Et ab magni consequatur, quae in repellat. Placeat deserunt vitae alias dignissimos!</p>
                </div><!--div class="Events"-->
                

            </div><!--div class="prgrssEvents"-->

            <div class="RankAttendance">
                <div class="rank">
                    <h4>Rank</h4>
                    <img src="../../resource/rank.png" alt="">
                </div><!--div class="rank"-->

                <div class="attendance">
                    <h4>Attendace</h4>
                    <img src="../../resource/sub3.png" alt="">
                </div><!--div class="attendance"-->

            </div><!--div class="RankAttendance"-->

        </div><!--div class="allBox"--> 

    </div><!--div class="page-wrapper"-->


    <script src="../../js/Student/StudentMenu.js"></script>
    <script src="../../js/Student/studentProfile.js"></script>
</body>
</html>