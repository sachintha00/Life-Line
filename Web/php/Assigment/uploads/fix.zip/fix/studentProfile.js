var profile = document.getElementById('profile');
profile.addEventListener('click',function(){
    const toggleMenu = document.querySelector('.menu');
    toggleMenu.classList.toggle('active');
});